These files are to be put in the server which CurveLock will call to.
